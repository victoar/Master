CREATE TABLE Respondent (     
	RespondentId SERIAL PRIMARY KEY,     
	Age INT,     
	Gender VARCHAR(255),     
	MaritalStatus VARCHAR(255),     
	Occupation VARCHAR(255),     
	Organization VARCHAR(255) 
); 

CREATE TABLE SocialMediaUsage (     
	SocialMediaUsageId SERIAL PRIMARY KEY,     
	socialMediaUsage BIT,     
	Platforms VARCHAR(255),     
	DailyTime VARCHAR(255),     
	NoPurposeFrequency INT,     
	DistractedFrequency INT,     
	RestlessWithoutSocialMedia INT
); 

CREATE TABLE MentalHealthStatus (      
	RespondentId INT,     
	SocialMediaUsageId INT,
	DistractibilityScale INT,     
	DifficultyConcentrating INT,     
	DepressedFrequency INT,     
	SleepIssuesScale INT,     
	PRIMARY KEY (RespondentId, SocialMediaUsageId ),
	FOREIGN KEY (RespondentId) REFERENCES Respondent (RespondentId),
	FOREIGN KEY (SocialMediaUsageId) REFERENCES SocialMediaUsage (SocialMediaUsageId)
);

CREATE TABLE INTERMEDIATE_TABLE (   
	RowId INT,
	Age INT,     
	Gender VARCHAR(255),     
	MaritalStatus VARCHAR(255),     
	Occupation VARCHAR(255),     
	Organization VARCHAR(255),
	socialMediaUsage BIT,     
	Platforms VARCHAR(255),     
	DailyTime VARCHAR(255),     
	NoPurposeFrequency INT,     
	DistractedFrequency INT,     
	RestlessWithoutSocialMedia INT,
	DistractibilityScale INT,     
	DifficultyConcentrating INT,     
	DepressedFrequency INT,     
	SleepIssuesScale INT
);

copy INTERMEDIATE_TABLE (RowId, Age, Gender, MaritalStatus, Occupation, Organization, socialMediaUsage, Platforms, DailyTime, NoPurposeFrequency, DistractedFrequency, RestlessWithoutSocialMedia, DistractibilityScale,DifficultyConcentrating,DepressedFrequency,SleepIssuesScale)
from '/Users/iuliachereji/Desktop/cleaned_dataset (3).csv'
with (format csv)

INSERT INTO Respondent (Age, Gender, MaritalStatus, Occupation, Organization)
SELECT Age, Gender, MaritalStatus, Occupation, Organization
FROM INTERMEDIATE_TABLE

INSERT INTO SocialMediaUsage(socialMediaUsage, Platforms, DailyTime, NoPurposeFrequency, DistractedFrequency, RestlessWithoutSocialMedia)
SELECT socialMediaUsage, Platforms, DailyTime, NoPurposeFrequency, DistractedFrequency, RestlessWithoutSocialMedia
FROM INTERMEDIATE_TABLE

INSERT INTO MentalHealthStatus(RespondentId, SocialMediaUsageId, DistractibilityScale,DifficultyConcentrating,DepressedFrequency,SleepIssuesScale)
SELECT R.RespondentId, SM.SocialMediaUsageId, DistractibilityScale,DifficultyConcentrating,DepressedFrequency,SleepIssuesScale
FROM INTERMEDIATE_TABLE IT
INNER JOIN Respondent R on IT.RowId=R.RespondentId
INNER JOIN SocialMediaUsage SM on IT.RowId=SM.SocialMediaUsageId


