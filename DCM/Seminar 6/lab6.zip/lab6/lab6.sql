-- Check for distinct rows in the Respondent table
SELECT COUNT(*) AS distinct_row_count
FROM (
    SELECT *
    FROM Respondent
    GROUP BY RespondentId, Age, Gender, MaritalStatus, Occupation, Organization
) AS unique_rows;

-- Check for distinct values in the Respondent table for the 'Gender' column
SELECT Gender, COUNT(*) AS value_count
FROM Respondent
GROUP BY Gender;

-- Check for distinct values in the MentalHealthStatus table for the 'DifficultyConcentrating' column
SELECT COUNT(*) AS total_rows, COUNT(DISTINCT DifficultyConcentrating) AS distinct_values_count
FROM MentalHealthStatus;

-- Check for missing values in Respondent table in the Occupation column
SELECT 
    COUNT(*) - COUNT(Occupation) AS Occupation_missing
FROM Respondent;

-- Range of values in the Respondent table for the 'Age' column
SELECT MIN(Age) AS min_age, MAX(Age) AS max_age
FROM Respondent;
 
-- Window functions on the entire table as one group (ordering by 'Gender')
SELECT
    RespondentId,
    Age,
    Gender,
    ROW_NUMBER() OVER (ORDER BY Gender ) AS row_number,
    MIN(Age) OVER () AS min_age,
    MAX(Age) OVER () AS max_age,
    AVG(Age) OVER () AS average_age,
    RANK() OVER (ORDER BY Age) AS rank_by_age,
    DENSE_RANK() OVER (ORDER BY Age) AS dense_rank_by_age,
    PERCENT_RANK() OVER (ORDER BY Age) AS cumulative_distribution,
    FIRST_VALUE(Age) OVER (ORDER BY Age) AS first_value_by_age,
    LAST_VALUE(Age) OVER (ORDER BY Age) AS last_value_by_age,
    LAG(Age) OVER (ORDER BY Age) AS previous_age,
    LEAD(Age) OVER (ORDER BY Age) AS next_age
FROM Respondent;
 
-- Window functions on groups based on 'Occupation' (ordering by 'Age')
SELECT
    RespondentId,
    Age,
    Gender,
    Occupation,
    ROW_NUMBER() OVER (PARTITION BY Occupation ORDER BY Age) AS row_number,
    MIN(Age) OVER (PARTITION BY Occupation) AS min_age,
    MAX(Age) OVER (PARTITION BY Occupation) AS max_age,
    AVG(Age) OVER (PARTITION BY Occupation) AS average_age,
    RANK() OVER (PARTITION BY Occupation ORDER BY Age) AS rank_by_age,
    DENSE_RANK() OVER (PARTITION BY Occupation ORDER BY Age) AS dense_rank_by_age,
    PERCENT_RANK() OVER (PARTITION BY Occupation ORDER BY Age) AS cumulative_distribution,
    FIRST_VALUE(Age) OVER (PARTITION BY Occupation ORDER BY Age) AS first_value_by_age,
    LAST_VALUE(Age) OVER (PARTITION BY Occupation ORDER BY Age) AS last_value_by_age,
    LAG(Age) OVER (PARTITION BY Occupation ORDER BY Age) AS previous_age,
    LEAD(Age) OVER (PARTITION BY Occupation ORDER BY Age) AS next_age
FROM Respondent;
